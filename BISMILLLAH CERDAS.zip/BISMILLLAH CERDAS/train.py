import numpy as np
import pandas as pd

# Load dataset from an Excel file
file_path = 'dataset2.xlsx'  # Replace with your Excel file path or name
data = pd.read_excel(file_path)

# Split the data into inputs and targets
X = data[['F', 'RE', 'LE']].values
y = data['jarak'].values.reshape(-1, 1)

# Normalize input data for better training performance
X_mean, X_std = X.mean(axis=0), X.std(axis=0)
X = (X - X_mean) / X_std

# Save mean and std for prediction normalization
np.save("weight5\\X_mean.npy", X_mean)
np.save("weight5\\X_std.npy", X_std)

# Neural Network Parameters
input_size = X.shape[1]  # 3 input features
hidden_size_1 = 50       # Increased neurons in the first hidden layer
hidden_size_2 = 40       # Increased neurons in the second hidden layer
hidden_size_3 = 30       # Increased neurons in the third hidden layer
hidden_size_4 = 20       # Added another hidden layer with neurons
output_size = 1          # Single output for distance

# Initialize weights and biases with He initialization
np.random.seed(42)
W1 = np.random.randn(input_size, hidden_size_1) * np.sqrt(2. / input_size)
b1 = np.zeros((1, hidden_size_1))
W2 = np.random.randn(hidden_size_1, hidden_size_2) * np.sqrt(2. / hidden_size_1)
b2 = np.zeros((1, hidden_size_2))
W3 = np.random.randn(hidden_size_2, hidden_size_3) * np.sqrt(2. / hidden_size_2)
b3 = np.zeros((1, hidden_size_3))
W4 = np.random.randn(hidden_size_3, hidden_size_4) * np.sqrt(2. / hidden_size_3)
b4 = np.zeros((1, hidden_size_4))
W5 = np.random.randn(hidden_size_4, output_size) * np.sqrt(2. / hidden_size_4)
b5 = np.zeros((1, output_size))

# Hyperparameters
learning_rate = 0.001  # Smaller learning rate
epochs = 25000          # Increased number of epochs
min_delta = 1e-4       # Minimum improvement in loss for early stopping
patience = 2000        # Early stopping patience
best_loss = float('inf')
patience_counter = 0

# Activation functions
def relu(x):
    return np.maximum(0, x)

def relu_derivative(x):
    return np.where(x > 0, 1, 0)

# Loss function (Mean Squared Error)
def compute_loss(y_true, y_pred):
    return np.mean((y_true - y_pred) ** 2)

# Training the neural network
for epoch in range(epochs):
    # Forward pass
    Z1 = np.dot(X, W1) + b1
    A1 = relu(Z1)
    Z2 = np.dot(A1, W2) + b2
    A2 = relu(Z2)
    Z3 = np.dot(A2, W3) + b3
    A3 = relu(Z3)
    Z4 = np.dot(A3, W4) + b4
    A4 = relu(Z4)
    Z5 = np.dot(A4, W5) + b5
    y_pred = Z5  # Linear activation in output layer for regression

    # Compute loss
    loss = compute_loss(y, y_pred)

    # Early stopping

    # Backward pass
    dZ5 = y_pred - y
    dW5 = np.dot(A4.T, dZ5) / X.shape[0]
    db5 = np.sum(dZ5, axis=0, keepdims=True) / X.shape[0]

    dA4 = np.dot(dZ5, W5.T)
    dZ4 = dA4 * relu_derivative(Z4)
    dW4 = np.dot(A3.T, dZ4) / X.shape[0]
    db4 = np.sum(dZ4, axis=0, keepdims=True) / X.shape[0]

    dA3 = np.dot(dZ4, W4.T)
    dZ3 = dA3 * relu_derivative(Z3)
    dW3 = np.dot(A2.T, dZ3) / X.shape[0]
    db3 = np.sum(dZ3, axis=0, keepdims=True) / X.shape[0]

    dA2 = np.dot(dZ3, W3.T)
    dZ2 = dA2 * relu_derivative(Z2)
    dW2 = np.dot(A1.T, dZ2) / X.shape[0]
    db2 = np.sum(dZ2, axis=0, keepdims=True) / X.shape[0]

    dA1 = np.dot(dZ2, W2.T)
    dZ1 = dA1 * relu_derivative(Z1)
    dW1 = np.dot(X.T, dZ1) / X.shape[0]
    db1 = np.sum(dZ1, axis=0, keepdims=True) / X.shape[0]

    # Update weights and biases
    W5 -= learning_rate * dW5
    b5 -= learning_rate * db5
    W4 -= learning_rate * dW4
    b4 -= learning_rate * db4
    W3 -= learning_rate * dW3
    b3 -= learning_rate * db3
    W2 -= learning_rate * dW2
    b2 -= learning_rate * db2
    W1 -= learning_rate * dW1
    b1 -= learning_rate * db1

    # Print loss every 100 epochs
    if epoch % 100 == 0:
        print(f"Epoch {epoch}, Loss: {loss}")

print("Training complete.")

# Save the model weights for future predictions
np.save("weight5\\W1.npy", W1)
np.save("weight5\\b1.npy", b1)
np.save("weight5\\W2.npy", W2)
np.save("weight5\\b2.npy", b2)
np.save("weight5\\W3.npy", W3)
np.save("weight5\\b3.npy", b3)
np.save("weight5\\W4.npy", W4)
np.save("weight5\\b4.npy", b4)
np.save("weight5\\W5.npy", W5)
np.save("weight5\\b5.npy", b5)

# Prediction Function
def predict(face_area, right_eye_area, left_eye_area):
    # Normalize inputs based on training data
    X_mean = np.load("weight5\\X_mean.npy")
    X_std = np.load("weight5\\X_std.npy")
    inputs = np.array([face_area, right_eye_area, left_eye_area])
    inputs = (inputs - X_mean) / X_std

    # Load trained weights
    W1 = np.load("weight5\\W1.npy")
    b1 = np.load("weight5\\b1.npy")
    W2 = np.load("weight5\\W2.npy")
    b2 = np.load("weight5\\b2.npy")
    W3 = np.load("weight5\\W3.npy")
    b3 = np.load("weight5\\b3.npy")
    W4 = np.load("weight5\\W4.npy")
    b4 = np.load("weight5\\b4.npy")
    W5 = np.load("weight5\\W5.npy")
    b5 = np.load("weight5\\b5.npy")

    # Forward pass for prediction
    Z1 = np.dot(inputs, W1) + b1
    A1 = relu(Z1)
    Z2 = np.dot(A1, W2) + b2
    A2 = relu(Z2)
    Z3 = np.dot(A2, W3) + b3
    A3 = relu(Z3)
    Z4 = np.dot(A3, W4) + b4
    A4 = relu(Z4)
    Z5 = np.dot(A4, W5) + b5
    predicted_distance = Z5[0, 0]  # Return single predicted value

    return predicted_distance

# Example usage of the prediction function
test_face_area = 16940  # Example input for face area
test_right_eye_area = 184  # Example input for right eye area
test_left_eye_area = 184   # Example input for left eye area
predicted_distance = predict(test_face_area, test_right_eye_area, test_left_eye_area)
print(f"Predicted Distance: {predicted_distance}")
