import cv2
import os



dir_caseFace = os.path.join("lib", 'haarcascade_frontalface_default.xml')
dir_caseLeye = os.path.join("lib", 'haarcascade_lefteye_2splits.xml')
dir_caseReye = os.path.join("lib", 'haarcascade_righteye_2splits.xml')
face_cascade = cv2.CascadeClassifier(dir_caseFace)
leftEye_cascade =cv2.CascadeClassifier(dir_caseLeye)
rightEye_cascade = cv2.CascadeClassifier(dir_caseReye)

cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    rgb_gray_scale = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = face_cascade.detectMultiScale(rgb_gray_scale, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    rEye = rightEye_cascade.detectMultiScale(rgb_gray_scale, scaleFactor=1.1, minNeighbors=80, minSize=(55, 55))
    lEye= leftEye_cascade.detectMultiScale(rgb_gray_scale, scaleFactor=1.1, minNeighbors=80, minSize=(55, 55))


    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
        cv2.putText(frame, 'face', (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

    for (x, y, w, h) in rEye:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(frame, 'Right Eye', (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    for (x, y, w, h) in lEye:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
        cv2.putText(frame, 'Left Eye', (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)



    cv2.imshow('Frame detection', frame)


    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


cap.release()
cv2.destroyAllWindows()
