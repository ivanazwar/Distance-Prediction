import mediapipe as mp
import cv2 as cv
from scipy.spatial import distance as dis
import time
import sklearn


import numpy as np
import tensorflow as tf
import numpy as np
#from tensorflow.keras.models import load_model
#from sklearn.preprocessing import StandardScaler

def relu(x):
    return np.maximum(0, x)


def predict(face_area, right_eye_area, left_eye_area):

    X_mean = np.load("weight4\\X_mean.npy")
    X_std = np.load("weight4\\X_std.npy")
    inputs = np.array([face_area, right_eye_area, left_eye_area])
    inputs = (inputs - X_mean) / X_std


    W1 = np.load("weight4\\W1.npy")
    b1 = np.load("weight4\\b1.npy")
    W2 = np.load("weight4\\W2.npy")
    b2 = np.load("weight4\\b2.npy")
    W3 = np.load("weight4\\W3.npy")
    b3 = np.load("weight4\\b3.npy")
    W4 = np.load("weight4\\W4.npy")
    b4 = np.load("weight4\\b4.npy")

    # Forward pass for prediction
    Z1 = np.dot(inputs, W1) + b1
    A1 = relu(Z1)
    Z2 = np.dot(A1, W2) + b2
    A2 = relu(Z2)
    Z3 = np.dot(A2, W3) + b3
    A3 = relu(Z3)
    Z4 = np.dot(A3, W4) + b4
    predicted_distance = Z4[0, 0]  # Extract the single predicted value

    return int(predicted_distance)  # Return as an integer for simplicity

def draw_landmarks(image, face_landmarks, landmark_indices, color):
    height, width = image.shape[:2]
    for index in landmark_indices:
        point = face_landmarks.landmark[index]
        point_scale = (int(point.x * width), int(point.y * height))
        cv.circle(image, point_scale, 1, color, 2)

def delta_jarak(image, point1, point2):
    height, width = image.shape[:2]
    point1 = int(point1.x * width), int(point1.y * height)
    point2 = int(point2.x * width), int(point2.y * height)
    return dis.euclidean(point1, point2)

def rasio_titik(face_landmarks, top_bottom, left_right, image):
    top, bottom = face_landmarks.landmark[top_bottom[0]], face_landmarks.landmark[top_bottom[1]]
    left, right = face_landmarks.landmark[left_right[0]], face_landmarks.landmark[left_right[1]]
    return delta_jarak(image, left, right) / delta_jarak(image, top, bottom)

def make_bounding(image, face_landmarks, eye_indices):
    height, width = image.shape[:2]
    x_coords = [int(face_landmarks.landmark[i].x * width) for i in eye_indices]
    y_coords = [int(face_landmarks.landmark[i].y * height) for i in eye_indices]
    return min(x_coords), min(y_coords), max(x_coords), max(y_coords)

face_mesh = mp.solutions.face_mesh.FaceMesh(static_image_mode=False, max_num_faces=1, min_detection_confidence=0.8)
face_detection = mp.solutions.face_detection.FaceDetection(model_selection=1, min_detection_confidence=0.5)

COLOR_RED = (0, 0, 255)
COLOR_GREEN = (0, 255, 0)
FACE = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400,
        377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109]
LEFT_EYE = [362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398]
RIGHT_EYE = [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246]
LEFT_EYE_TOP_BOTTOM = [386, 374]
LEFT_EYE_LEFT_RIGHT = [263, 362]
RIGHT_EYE_TOP_BOTTOM = [159, 145]
RIGHT_EYE_LEFT_RIGHT = [133, 33]
#model = load_model('model.h5')
#scaler = StandardScaler()


#def predict_distance(face_area, right_eye_area, left_eye_area):

   # input_data = np.array([[face_area, right_eye_area, left_eye_area]])
    #scaled_data = scaler.transform(input_data)
    #predicted_distance = model.predict(scaled_data)
    #return predicted_distance[0][0]


capture = cv.VideoCapture(1)
if not capture.isOpened():
    print("Error: Can't access the camera.")
    exit()

start_time = time.time()
frame_count_fps = 0
fps = 0

while True:
    result, image = capture.read()
    newFrame = cv.resize(image, (800, 600))
    if not result:
        break
    newFrame = cv.flip(newFrame, 1)
    image_rgb = cv.cvtColor(newFrame, cv.COLOR_BGR2RGB)
    detections = face_detection.process(image_rgb)
    frame_count_fps += 1

    elapsed_time = time.time() - start_time
    if elapsed_time > 1:
        fps = frame_count_fps / elapsed_time
        start_time = time.time()
        frame_count_fps = 0

    bbox_terbesar = None
    face_terbesar = 0

    if detections.detections:
        for detection in detections.detections:
            bbox = detection.location_data.relative_bounding_box
            ih, iw, _ = newFrame.shape
            x, y, w, h = int(bbox.xmin * iw), int(bbox.ymin * ih), int(bbox.width * iw), int(bbox.height * ih)
            center_x, center_y = x + w // 2, y + h // 2
            face_area = w * h
            #cv.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
            if face_area > face_terbesar:
                face_terbesar = face_area
                bbox_terbesar = (x, y, w, h)
    if bbox_terbesar:
        x, y, w, h = bbox_terbesar
        center_x, center_y = x + w // 2, y + h // 2
        #cv.rectangle(newFrame, (x, y), (x + w, y + h), (0, 255, 0), 2)

    outputs = face_mesh.process(image_rgb)
    if outputs.multi_face_landmarks:
        for face_landmarks in outputs.multi_face_landmarks:
            #draw_landmarks(image, face_landmarks, FACE, (255, 217, 25))
            #draw_landmarks(image, face_landmarks, LEFT_EYE, COLOR_GREEN)
            #draw_landmarks(image, face_landmarks, RIGHT_EYE, COLOR_RED)

            left_eye_bbox = make_bounding(newFrame, face_landmarks, LEFT_EYE)
            right_eye_bbox = make_bounding(newFrame, face_landmarks, RIGHT_EYE)
            face_bbox = make_bounding(newFrame, face_landmarks, FACE)

            face_bbox_width = face_bbox[2] - face_bbox[0]
            face_bbox_height = face_bbox[3] - face_bbox[1]
            face_bbox_wide = face_bbox_width * face_bbox_height
            center_bbox_x = (face_bbox[2] + face_bbox[0])//2
            center_bbox_y = (face_bbox[3] + face_bbox[1] )//2
            cv.rectangle(newFrame, (face_bbox[0]-10, face_bbox[1]-10), (face_bbox[2]+10, face_bbox[3]+10), (255, 217, 25),2)
            #cv.putText(image, 'face',(face_bbox[0], face_bbox[1] - 20), cv.FONT_HERSHEY_SIMPLEX, 0.5, (255, 217, 25), 2)
            cv.putText(newFrame, f"face: {face_bbox_wide}", (face_bbox[0], face_bbox[1] - 20), cv.FONT_HERSHEY_SIMPLEX, 0.5, (204, 102, 0), 2, cv.LINE_AA)
            #cv.circle(image, (center_bbox_x, center_bbox_y), 20, (0, 0, 255), -1)

            L_bbox_width = left_eye_bbox[2] - left_eye_bbox[0]
            L_bbox_height = left_eye_bbox[3] - left_eye_bbox[1]
            L_bbox_wide = L_bbox_width * L_bbox_height
            cv.rectangle(newFrame, (left_eye_bbox[0]-10, left_eye_bbox[1]-10), (left_eye_bbox[2]+10, left_eye_bbox[3]+10), COLOR_GREEN, 2)
            cv.putText(newFrame, 'Left Eye',(left_eye_bbox[0], left_eye_bbox[1] - 15), cv.FONT_HERSHEY_SIMPLEX, 0.2, COLOR_GREEN, 1)
            center_bboxL_x = (left_eye_bbox[2] + left_eye_bbox[0]) // 2
            center_bboxL_y = (left_eye_bbox[3] + left_eye_bbox[1]) // 2
            cv.circle(newFrame, (center_bboxL_x, center_bboxL_y), 2, (0, 0, 255), -1)

            R_bbox_width = right_eye_bbox[2] - right_eye_bbox[0]
            R_bbox_height = right_eye_bbox[3] - right_eye_bbox[1]
            R_bbox_wide = R_bbox_width * R_bbox_height
            cv.rectangle(newFrame, (right_eye_bbox[0]-10, right_eye_bbox[1]-10), (right_eye_bbox[2]+10, right_eye_bbox[3]+10), COLOR_RED, 2)
            cv.putText(newFrame, 'Right Eye', (right_eye_bbox[0], right_eye_bbox[1]-15), cv.FONT_HERSHEY_SIMPLEX, 0.2, COLOR_RED, 1)
            center_bboxR_x = (right_eye_bbox[2] + right_eye_bbox[0]) // 2
            center_bboxR_y = (right_eye_bbox[3] + right_eye_bbox[1]) // 2
            cv.circle(newFrame, (center_bboxR_x, center_bboxR_y), 2, (0, 0, 255), -1)

            ratio_left = rasio_titik(face_landmarks, LEFT_EYE_TOP_BOTTOM, LEFT_EYE_LEFT_RIGHT, newFrame)

            cv.putText(newFrame, f"Coordinate: {center_x};{center_y}", (20, 20), cv.FONT_HERSHEY_SIMPLEX, 0.5, (204, 102, 0), 1, cv.LINE_AA)
            cv.putText(newFrame, f"FPS: {fps:.2f}", (20, 40), cv.FONT_HERSHEY_SIMPLEX, 0.5, (204, 102, 0), 1, cv.LINE_AA)
            cv.putText(newFrame, f"P-Face: {face_bbox_height};L-Face: {face_bbox_width};W-Face: {face_bbox_wide}", (20, 60), cv.FONT_HERSHEY_SIMPLEX, 0.5, (204, 102, 0), 1, cv.LINE_AA)
            cv.putText(newFrame, f"P-Left: {L_bbox_height};L-Left: {L_bbox_width};W-left: {L_bbox_wide}",
                       (20, 80), cv.FONT_HERSHEY_SIMPLEX, 0.5, (204, 102, 0), 1, cv.LINE_AA)
            cv.putText(newFrame, f"P-Right: {R_bbox_height};L-Right: {R_bbox_width};W-Right: {R_bbox_wide}",
                       (20, 100), cv.FONT_HERSHEY_SIMPLEX, 0.5, (204, 102, 0), 1, cv.LINE_AA)

            test_face_area = 51240  # Replace with actual face area input
            test_right_eye_area = 360  # Replace with actual right eye area input
            test_left_eye_area = 387  # Replace with actual left eye area input

            #predicted_distance = predict_distance(face_area, right_eye_area, left_eye_area)
            predicted_distance = predict(face_bbox_wide, R_bbox_wide, L_bbox_wide)
            print(f"Predicted Distance: {int(predicted_distance)}")


            cv.rectangle(newFrame, (50, 450), (300, 530), (255, 255, 255), 90)
            cv.putText(newFrame, f"F: {face_bbox_wide}", (30, 450), cv.FONT_HERSHEY_SIMPLEX, 0.8, (204, 102, 0), 2, cv.LINE_AA)
            cv.putText(newFrame, f"RE: {R_bbox_wide}", (30, 480), cv.FONT_HERSHEY_SIMPLEX, 0.8, COLOR_RED, 2,
                       cv.LINE_AA)
            cv.putText(newFrame, f"LE: {L_bbox_wide}", (30, 510), cv.FONT_HERSHEY_SIMPLEX, 0.8, COLOR_GREEN, 2,
                       cv.LINE_AA)
            cv.putText(newFrame, f"Predicted Distance: {int(predicted_distance)}", (30, 540), cv.FONT_HERSHEY_SIMPLEX, 0.8, (255,0,191), 2,cv.LINE_AA)



            # Make prediction

            #print(f"Predicted Distance: {predicted_distance}")

            #cv.rectangle(newFrame, (50, 480), (160, 580), (255, 255, 255), 50)



    cv.imshow("TUGAS CERDASS", newFrame)
    if cv.waitKey(1) & 0xFF == 27:
        break

capture.release()
cv.destroyAllWindows()
